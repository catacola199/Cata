package com.c.myrecyclerview

object HeroesData {
    private val heroNames = arrayOf("Ahmad Dahlan",
        "Ahmad Yani",
        "Sutomo",
        "Gatot Soebroto",
        "Ki Hadjar Dewantarai",
        "Mohammad Hatta",
        "Soedirman",
        "Soekarno",
        "Soepomo",
        "Tan Malaka")

    private val heroDetails = arrayOf(
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",

    )

    private val heroesImages = intArrayOf(R.drawable.ahmad_dahlan,
        R.drawable.ahmad_yani,
        R.drawable.bung_tomo,
        R.drawable.gatot_subroto,
        R.drawable.ki_hajar_dewantara,
        R.drawable.moh_hatta,
        R.drawable.sudirman,
        R.drawable.sukarno,
        R.drawable.supomo,
        R.drawable.tan_malaka)

    val listData: ArrayList<Hero>
        get() {
            val list = arrayListOf<Hero>()
            for (position in heroNames.indices) {
                val hero = Hero()
                hero.name = heroNames[position]
                hero.detail = heroDetails[position]
                hero.photo = heroesImages[position]
                list.add(hero)
            }
            return list
        }
}