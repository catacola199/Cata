package com.c.videogame

object DataGame {private val heroNames = arrayOf(
        "BattleField 4",
        "Black Dessert Online Remastered",
        "Call Of Duty Modern Warfrane",
        "Counter Strike Global Offensive",
        "Defend Of The Ancient 2 (DOTA 2)",
        "Fornite",
        "Forza Horizon 4",
        "Grand Theft Auto 5 (GTA 5)",
        "Minecraft",
        "Naruto Shippunden Ultimate Ninja Strom 4",
        "Pro Evolution Soccer 2019",
        "PlayerUnknown's Battlegrounds"


)

    private val heroDetails = arrayOf(
        "Single Player dan Multiplayer adalah dua buah mode yang secara konsisten berjalan beriringan, hampir di sebagian besar game yang dirilis di industri game saat ini. Single player seringkali menjadi fokus, sebuah pintu gerbang utama bagi game-game untuk tampil optimal dan menawarkan pengalaman yang memang diinginkan oleh sang developer. Sementara multiplayer menjadi opsi tambahan untuk memperpanjang masa hidup sang game sendiri, sekaligus mengakomodasi kebutuhan untuk mencicipi pengalaman ini bersama gamer-gamer lain di seluruh dunia. Namun, konsep ini justru berbalik di franchise FPS andalan EA dan DICE – Battlefield. Game yang satu ini memang selalu dikenal karena kemampuan untuk menghasilkan pengalaman multiplayer yang luar biasa. Sesuatu yang diakui oleh pihak DICE sendiri.",
        "Genre MMORPG memang tidak menemui jalan mulus dalam persaingan di pasaran saat ini. Kurangnya fokus jalan cerita dan konsep gameplay yang sangat repetitif adalah dua alasan terbesar kenapa banyak gamer tidak menaruh harapan besar kepada genre ini. Tapi bagi sebagian developer kecil, genre ini adalah kesempatan mereka untuk menciptakan sebuah game yang lebih sederhana namun dapat bertahan lama hingga tahun ke tahun. Jika ada satu game yang berhasil mencapai tujuan ini, mungkin Black Desert Online adalah salah satu game MMORPG yang paling banyak mendapat sorotan selama beberapa tahun terakhir. Tidak hanya memperlihatkan wujud sebuah game MMORPG paling menawan, tapi game ini juga berusaha untuk memberikan kesempurnaan dari berbagai konsep yang ingin diwujudkannya.",
        "Modern Warfare adalah permainan pertama dalam seri Call of Duty yang berlatarkan perang modern, dan menampilkan beberapa senjata, perlengkapan dan kendaraan perang modern dari beberapa negara terkenal, salah satunya adalah Amerika Serikat, Inggris dan Rusia. Jika pada permainan sebelumnya pemain akan memakai senapan lama seperti Bren, MP40 dan PPSh-41, maka di dalam Modern Warfare pemain akan memakai senapan modern seperti AK-47, M4A1 dan G36C. Pemain juga akan merasakan pengalaman menjadi salah satu penembak senjata pesawat AC-130, sesuatu yang hanya bisa dirasakan oleh tentara Angkatan Udara saja.",
        "Counter Strike – Global Offensive sendiri tetap dibangun dengan menggunakan engine Source, namun dengan versi yang sudah lebih disempurnakan. Hal ini tentu saja membuatnya datang dengan visualisasi yang boleh dikatakan setara dengan franchise game serupa yang dirilis saat ini, dengan desain karakter dan setting yang juga lebih baik. Uniknya, bagi para gamer yang sempat mencicipi game ini di masa lalu, kehadiran seri terbaru ini tidak lantas membuatnya berbeda dan “asing”.",
        "Dota 2 adalah sebuah permainan Arena pertarungan daring multipemain, dan merupakan sekuel dari Defense of the Ancients mod pada Warcraft 3: Reign of Chaos dan Warcraft 3: The Frozen Throne. DotA 2 dikembangkan oleh Valve Corporation, terbit juli 2013 dota 2 dapat dimainkan secara gratis pada sistem operasi Microsoft Windows, OS X and Linux. Dota 2 dapat dimainkan secara eksklusif melalui distributor resmi valve, Steam.\n" +
                "\n" +
                "Dota 2 dimainkan oleh 2 tim yang beranggota 5 orang pemain, setiap tim memiliki markas yang berada dipojok peta, setiap markas memiliki satu bangunan bernama \"Ancient\", Di mana tim harus berusaha menghancurkan \"Ancient\" tim lawan agar dapat memenangkan pertandingan. Setiap pemain hanya dapat mengontrol satu karakter \"Hero\" yang berfokus pada menaikan level, mengumpulkan gold, membeli item dan melawan tim lawan untuk menang.",
        "Fortnite Battle Royale, yaitu permainan battle royale yang melibatkan hingga 100 pemain yang bertarung di ruangan yang semakin kecil dan setiap pemain berupaya untuk menjadi orang terakhir yang selamat. Modus permainan ini dirilis pada tahun 2017. Battle Royale tersedia di serambi Microsoft Windows, macOS, PlayStation 4, Xbox One, Nintendo Switch dan perangkat iOS dan Android.",
        "Forza Horizon 2 adalah sebuah permainan video balap dunia terbuka yang dikembangkan oleh konsol-konsol Xbox One dan Xbox 360 milik Microsoft. Permainan tersebut adalah sekuel dari permainan video tahun 2012 Forza Horizon dan instalment ketujuh dalam serial Forza.",
        "Grand Theft Auto V (Disingkat GTA V) adalah game aksi dan petualangan yang dikembangkan oleh Rockstar North dan di terbitkan oleh Rockstar Games. Game ini terbit pada tanggal 17 september 2013 untuk console Playstation 3 dan Xbox 360. Game ini adalah game kelima belas dari seluruh game GTA. Pengembang permainan ini, Rockstar Games membuat Grand Theft Auto V bisa dimainkan di PlayStation 4, Xbox One, dan juga di PC.",
        "Minecraft adalah permainan sandbox yang diciptakan oleh Mojang yang dipimpin oleh Markus 'Notch' Persson dari Swedia. Setelah Persson pergi, pada tahun 2011, Jens 'Jeb' Bergensten mengambil alih kendali Minecraft sebagai Developer Game Mojang.\n" +
                "\n" +
                "Minecraft difokuskan pada Kreativitas dan Pembangunan, yang memungkinkan pemain untuk membangun apapun dari kubus bertekstur dalam dunia 3D.",
        "Naruto Shippuden: Ultimate Ninja Storm 4 yang masih digarap oleh CyberConnect 2 menghadirkan gameplay fighting yang sederhana namun seru, Story Mode yang bisa mengingatkanmu dengan momen-momen bab akhir dari kisah Naruto, dan puluhan karakter yang bisa kamu coba satu per satu. Sayangnya, seluruh konten yang dihadirkan dalam Naruto Shippuden: Ultimate Ninja Storm 4 mungkin tidak selalu bisa memuaskanmu.",
        " Pada mulanya, permainan video ini masih bersaudara dengan International Superstar Soccer yang dirilis lebih awal dan dirilis dalam dua versi berbeda: Pro Evolution Soccer untuk seluruh dunia dan Winning Eleven di Jepang. Seri tersebut telah mendapat banyak kritik dan sukses secara komersial.\n" +
                "\n" +
                "PES merupakan salah satu contoh permainan video yang digunakan secara luas dalam olahraga elektronik (eSports). PES League (atau PES World Finals dalam versi sebelumnya) adalah kejuaraan resmi olahraga elektronik yang diselenggarakan setiap tahun sejak 2010. PES League memiliki partai tunggal (1v1) dan sejak 2018 sudah memiliki partai tim (3v3).",
        "PlayerUnknown's Battlegrounds (sering disingkat PUBG) adalah sebuah permainan dengan genre battle royale, yang para pemainnya bisa bermain dengan 100 orang sekaligus secara daring. Di dalam permainan ini pemain bisa bermain solo, tim 2 orang, dan tim 4 orang, serta bisa mengundang teman untuk bergabung ke dalam permainan sebagai tim."
           )

    private val heroesImages = intArrayOf(
        R.drawable.battlefield4,
        R.drawable.bdo,
        R.drawable.callofduty,
        R.drawable.csgo,
        R.drawable.dota2,
        R.drawable.fortnite,
        R.drawable.forza,
        R.drawable.gta5,
        R.drawable.minecraft,
        R.drawable.naruto,
        R.drawable.pes,
        R.drawable.pubg)

    val listData: ArrayList<Game>
        get() {
            val list = arrayListOf<Game>()
            for (position in heroNames.indices) {
                val hero = Game()
                hero.name = heroNames[position]
                hero.detail = heroDetails[position]
                hero.photo = heroesImages[position]
                list.add(hero)
            }
            return list
        }
}