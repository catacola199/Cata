package com.c.videogame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvGame: RecyclerView
    private var list: ArrayList<Game> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rvGame = findViewById(R.id.rv_game)
        rvGame.setHasFixedSize(true)
        list.addAll(DataGame.listData)
        showRecyclerList()
    }
    private fun showRecyclerList() {
        rvGame.layoutManager = LinearLayoutManager(this)
        val gameadapter = AdapterGame(list)
        rvGame.adapter = gameadapter

        gameadapter.setOnItemClickCallback (object : AdapterGame.OnItemClickCallback {
            override fun onItemClicked(data: Game) {
                showSelectedGame(data)
            }
        })
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when (selectedMode) {
            R.id.action_list -> {
                showRecyclerList()
            }

            R.id.data -> {
                val IntentAbout = Intent(this, Profile::class.java)
                startActivity(IntentAbout)
            }


        }
    }
    private fun showSelectedGame(gm : Game) {
        Toast.makeText(this, gm.name, Toast.LENGTH_SHORT).show()
    }
}
