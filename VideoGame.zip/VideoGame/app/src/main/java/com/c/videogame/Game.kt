package com.c.videogame

class Game (
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0
)